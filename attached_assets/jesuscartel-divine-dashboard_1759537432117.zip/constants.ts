
import { ArtistProfile, Song } from './types';

export const mockArtistData: ArtistProfile = {
  Sunday: { songs: 12, revenue: 15420.50, streams: 245000, growth: '+24%' },
  iMan: { songs: 18, revenue: 22100.75, streams: 180000, growth: '+31%' },
  Ebube: { songs: 25, revenue: 8940.25, streams: 95000, growth: '+18%' }
};

export const mockSongs: Song[] = [
  {
    id: 1,
    title: "PEMP (Pressure Elevates My Purpose)",
    artist: "Sunday",
    writers: ["Ebube"],
    producer: "iMan",
    status: "blockchain_verified",
    revenue: 4256.78,
    streams: 125623,
    aiScore: 94,
    syncOpportunities: 7,
    cover: "🎵"
  },
  {
    id: 2,
    title: "Divine Flow",
    artist: "Sunday ft. iMan",
    writers: ["Ebube", "Holy Spirit"],
    producer: "iMan",
    status: "ai_optimized",
    revenue: 2180.45,
    streams: 87450,
    aiScore: 89,
    syncOpportunities: 12,
    cover: "✨"
  },
  {
    id: 3,
    title: "Heaven's Beat",
    artist: "iMan",
    writers: ["Ebube"],
    producer: "iMan",
    status: "trending",
    revenue: 3420.90,
    streams: 156780,
    aiScore: 96,
    syncOpportunities: 15,
    cover: "👑"
  }
];
