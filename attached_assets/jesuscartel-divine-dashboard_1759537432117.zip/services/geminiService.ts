
import { GoogleGenAI, Type } from "@google/genai";
import { AiInsight, Song } from "../types";

// The API key is expected to be set in the environment.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const responseSchema = {
    type: Type.ARRAY,
    items: {
        type: Type.OBJECT,
        properties: {
            type: { type: Type.STRING, description: "The type of insight. Can be 'revenue_boost', 'trend_prediction', or 'sync_match'." },
            title: { type: Type.STRING, description: "A catchy title for the insight." },
            message: { type: Type.STRING, description: "A descriptive message explaining the insight." },
            confidence: { type: Type.INTEGER, description: "A confidence score for the insight, from 80 to 99." },
            action: { type: Type.STRING, description: "A short, actionable suggestion, like 'View Opportunities' or 'Submit Pitch'." }
        },
        required: ["type", "title", "message", "confidence", "action"]
    }
};

export const getAiInsights = async (catalog: Song[]): Promise<AiInsight[]> => {
    try {
        const songDataForPrompt = catalog.map(song => ({ title: song.title, artist: song.artist, genre: "Gospel/Christian Hip-Hop" }));
        
        const prompt = `
        You are 'Divine AI', an expert A&R and music publishing assistant for 'JesusCartel Publishing', a publisher focused on Gospel, Christian Hip Hop, and inspirational music. 
        Based on the following catalog data, generate exactly 3 actionable, creative, and specific insights to help maximize revenue and reach.
        For each insight, provide a title, a descriptive message, a confidence score between 80 and 99, a suggested action, and classify its type as 'revenue_boost', 'trend_prediction', or 'sync_match'.
        Ensure the insights are directly related to the provided song catalog.

        Catalog Data: ${JSON.stringify(songDataForPrompt)}
        `;

        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: responseSchema,
                temperature: 0.8,
            },
        });

        const jsonText = response.text.trim();
        if (!jsonText) {
            throw new Error("The AI returned an empty response. This may be due to content filtering or other safeguards.");
        }
        
        const insights: AiInsight[] = JSON.parse(jsonText);
        return insights;

    } catch (error) {
        console.error("Error fetching AI insights:", error);
        // Re-throw the error to be handled by the UI component
        throw error;
    }
};
