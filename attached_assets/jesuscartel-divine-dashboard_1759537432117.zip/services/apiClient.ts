import { getAiInsights as getInsightsFromGemini } from './geminiService';
import { AiInsight, Song } from '../types';

/**
 * This API client acts as a bridge between the UI and the data sources.
 * In a production environment with a dedicated backend, these functions would
 * make fetch() calls to your API endpoints (e.g., fetch('/api/insights')).
 *
 * For now, it calls the Gemini service directly, but this structure makes
 * the application "backend-ready".
 */
const apiClient = {
  /**
   * Fetches AI-powered insights for the given song catalog.
   * @param catalog - An array of Song objects.
   * @returns A promise that resolves to an array of AiInsight objects.
   */
  getAiInsights: async (catalog: Song[]): Promise<AiInsight[]> => {
    // In a real backend setup, this would be:
    // const response = await fetch('/api/ai-insights', {
    //   method: 'POST',
    //   headers: { 'Content-Type': 'application/json' },
    //   body: JSON.stringify({ catalog }),
    // });
    // if (!response.ok) {
    //   const errorData = await response.json();
    //   throw new Error(errorData.message || 'Failed to fetch insights');
    // }
    // return response.json();

    // For the current client-side architecture, we call the Gemini service directly.
    return getInsightsFromGemini(catalog);
  },
};

export default apiClient;
