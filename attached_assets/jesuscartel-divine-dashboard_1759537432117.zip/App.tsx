
import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import Placeholder from './components/Placeholder';
import { Brain } from './components/icons';
import { Section } from './types';

const App: React.FC = () => {
  const [activeSection, setActiveSection] = useState<Section>('dashboard');

  const renderContent = () => {
    switch (activeSection) {
      case 'dashboard':
        return <Dashboard />;
      default:
        return <Placeholder sectionName={activeSection} />;
    }
  };

  return (
    <div className="flex h-screen bg-gradient-to-br from-gray-50 to-purple-50 text-gray-800">
      <Sidebar activeSection={activeSection} setActiveSection={setActiveSection} />
      <main className="flex-1 overflow-y-auto">
        <div className="p-8">
          {renderContent()}
        </div>
        
        <div className="fixed bottom-8 right-8 group">
          <button className="bg-gradient-to-r from-purple-600 to-pink-600 text-white p-4 rounded-full shadow-2xl hover:shadow-purple-400/50 transition-all duration-300 transform group-hover:scale-110 group-hover:rotate-12 animate-pulse hover:animate-none">
            <Brain size={28} />
          </button>
           <div className="absolute bottom-full mb-2 right-1/2 translate-x-1/2 w-48 bg-gray-800 text-white text-center text-xs rounded py-1 px-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none">
            Divine AI Assistant
            <div className="absolute top-full left-1/2 -translate-x-1/2 w-0 h-0 border-x-4 border-x-transparent border-t-4 border-t-gray-800"></div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default App;
