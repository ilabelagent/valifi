
import React from 'react';
import { Section } from '../types';
import { 
  Crown, Music, Users, DollarSign, Brain, Film, Bitcoin, BarChart3, 
  Smartphone, Settings, Zap, Award, LogOut 
} from './icons';

interface SidebarProps {
  activeSection: Section;
  setActiveSection: (section: Section) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeSection, setActiveSection }) => {
  const menuItems = [
    { id: 'dashboard' as Section, label: 'Heaven\'s Dashboard', icon: Crown, badge: null },
    { id: 'songs' as Section, label: 'Divine Catalog', icon: Music, badge: '55' },
    { id: 'artists' as Section, label: 'Trinity Profiles', icon: Users, badge: null },
    { id: 'royalties' as Section, label: 'Blessed Revenue', icon: DollarSign, badge: '+$47K' },
    { id: 'ai-assistant' as Section, label: 'Divine AI', icon: Brain, badge: 'Active' },
    { id: 'sync' as Section, label: 'Sync Heaven', icon: Film, badge: '23' },
    { id: 'blockchain' as Section, label: 'Sacred Chain', icon: Bitcoin, badge: 'New' },
    { id: 'analytics' as Section, label: 'Heavenly Insights', icon: BarChart3, badge: null },
    { id: 'mobile' as Section, label: 'Mobile Ministry', icon: Smartphone, badge: null },
    { id: 'settings' as Section, label: 'Divine Settings', icon: Settings, badge: null }
  ];

  return (
    <div className="w-72 bg-gradient-to-br from-purple-900 via-purple-800 to-indigo-900 text-white h-screen p-6 shadow-2xl flex flex-col">
      <div className="flex-shrink-0">
        <div className="flex items-center space-x-3 mb-2">
          <Crown className="text-gold-400" size={32} />
          <div>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-gold-300 to-yellow-400 bg-clip-text text-transparent">
              JesusCartel
            </h1>
            <p className="text-xs text-purple-300">Heaven's Best Publishing</p>
          </div>
        </div>
        <div className="bg-purple-700/50 rounded-lg p-3 mt-4">
          <div className="flex items-center space-x-2">
            <Zap className="text-yellow-400" size={16} />
            <span className="text-sm font-medium">AI Engine Active</span>
          </div>
          <div className="text-xs text-purple-200 mt-1">Processing 247 insights</div>
        </div>
      </div>
      
      <nav className="space-y-2 mt-8 flex-grow overflow-y-auto">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeSection === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveSection(item.id)}
              className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all duration-200 group ${
                isActive 
                  ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white shadow-lg transform scale-105' 
                  : 'text-purple-200 hover:bg-purple-700/50 hover:text-white'
              }`}
            >
              <div className="flex items-center space-x-3">
                <Icon size={20} className={isActive ? 'text-gold-300' : ''} />
                <span className="font-medium">{item.label}</span>
              </div>
              {item.badge && (
                <span className={`text-xs px-2 py-1 rounded-full font-bold ${
                    isActive ? 'bg-white text-purple-700' : 'bg-gold-500 text-purple-900'
                }`}>
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>
      
      <div className="flex-shrink-0 mt-4">
        <div className="bg-gradient-to-r from-purple-600 to-pink-600 rounded-lg p-4 mb-4">
          <div className="flex items-center space-x-2 mb-2">
            <Award className="text-yellow-300" size={16} />
            <span className="text-sm font-bold">Pro Plan Active</span>
          </div>
          <div className="text-xs text-purple-100">Unlimited songs • AI features • Blockchain</div>
        </div>
        <button className="w-full flex items-center space-x-3 px-4 py-3 text-purple-200 hover:bg-purple-700/50 rounded-xl transition-colors">
          <LogOut size={20} />
          <span>Sign Out</span>
        </button>
      </div>
    </div>
  );
};

export default Sidebar;
