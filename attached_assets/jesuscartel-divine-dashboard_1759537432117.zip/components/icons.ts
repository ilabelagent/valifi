
export { 
  User, Music, DollarSign, Brain, Upload, Users, BarChart3, Settings, 
  LogOut, Plus, Search, Filter, Crown, Zap, Globe, Shield, Smartphone,
  TrendingUp, Award, Film, Gamepad2, CreditCard, Bitcoin, Wallet, 
  PieChart, LineChart, Bell, Mail, Calendar, FileText, Download, Share2, 
  Eye, Star, Heart, Play, Pause, SkipForward, SkipBack, Volume2, Repeat,
  Loader2, AlertTriangle, Lightbulb
} from 'lucide-react';
