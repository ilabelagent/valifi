import React, { useState, useEffect } from 'react';
import StatCard from './StatCard';
import ArtistCard from './ArtistCard';
import AiInsightCard from './AiInsightCard';
import SongRow from './SongRow';
import { mockArtistData, mockSongs } from '../constants';
import apiClient from '../services/apiClient';
import { AiInsight } from '../types';
import { Music, DollarSign, Brain, Film, Upload, AlertTriangle, Loader2 } from './icons';

const Dashboard: React.FC = () => {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [insights, setInsights] = useState<AiInsight[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const fetchInsights = async () => {
      try {
        setIsLoading(true);
        setError(null);
        const fetchedInsights = await apiClient.getAiInsights(mockSongs);
        setInsights(fetchedInsights);
      } catch (err) {
        let message = "Failed to fetch divine insights. Please try again later.";
        if (err instanceof Error) {
          // Check for common permission error and provide a more helpful message.
          if (err.message.includes("PERMISSION_DENIED")) {
            message = "Permission Denied. Please check if the API key is correct and has the required permissions enabled in the Google AI console.";
          } else {
            message = err.message;
          }
        }
        setError(message);
        console.error("Error details:", err);
      } finally {
        setIsLoading(false);
      }
    };

    fetchInsights();
  }, []);

  const stats = [
    { label: 'Total Songs', value: '55', change: '+8 this month', icon: Music, gradient: 'from-blue-500 to-purple-600', detail: 'Across all personas' },
    { label: 'Monthly Revenue', value: '$47,235', change: '+32.4%', icon: DollarSign, gradient: 'from-green-500 to-emerald-600', detail: 'AI optimized earnings' },
    { label: 'AI Optimizations', value: '247', change: '+15 today', icon: Brain, gradient: 'from-purple-500 to-pink-600', detail: 'Active improvements' },
    { label: 'Sync Opportunities', value: '34', change: '+7 matched', icon: Film, gradient: 'from-orange-500 to-red-600', detail: 'AI-matched placements' }
  ];
  
  return (
    <div className="space-y-8">
      <div className="flex justify-between items-start flex-wrap gap-4">
        <div>
          <h2 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
            Heaven's Dashboard
          </h2>
          <p className="text-gray-500 mt-2">
            {currentTime.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
          </p>
        </div>
        <div className="flex space-x-4">
          <button className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-6 py-3 rounded-xl shadow-lg hover:shadow-xl hover:-translate-y-1 transition-all duration-300 flex items-center space-x-2">
            <Upload size={16} />
            <span>Upload Divine Track</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => <StatCard key={index} {...stat} />)}
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {Object.entries(mockArtistData).map(([artist, data]) => (
          <ArtistCard key={artist} artist={artist} data={data} />
        ))}
      </div>

      <div className="bg-gradient-to-br from-purple-50 to-indigo-50 rounded-2xl p-8 border border-purple-200">
        <div className="flex items-center space-x-3 mb-6">
          <Brain className="text-purple-600" size={28} />
          <h3 className="text-2xl font-bold text-gray-900">Divine AI Insights</h3>
          <span className="bg-purple-100 text-purple-800 px-3 py-1 rounded-full text-sm font-bold animate-pulse">Live</span>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {isLoading ? (
            Array.from({ length: 3 }).map((_, index) => (
              <div key={index} className="bg-white rounded-xl p-6 shadow-lg border border-gray-100 animate-pulse">
                <div className="flex items-start space-x-4">
                  <div className="bg-purple-100 p-3 rounded-lg w-12 h-12"></div>
                  <div className="flex-1 space-y-3">
                    <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                    <div className="h-3 bg-gray-200 rounded w-full"></div>
                    <div className="h-3 bg-gray-200 rounded w-5/6"></div>
                  </div>
                </div>
              </div>
            ))
          ) : error ? (
            <div className="col-span-3 bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded-md flex items-center space-x-4">
              <AlertTriangle className="text-red-500" size={24} />
              <div>
                <p className="font-bold">Error Loading Insights</p>
                <p>{error}</p>
              </div>
            </div>
          ) : (
            insights.map((insight, index) => <AiInsightCard key={index} insight={insight} />)
          )}
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-100">
        <div className="bg-gradient-to-r from-purple-600 to-pink-600 p-6">
          <h3 className="text-2xl font-bold text-white">Top Performing Divine Tracks</h3>
          <p className="text-purple-100">Your heavenly hits making waves</p>
        </div>
        <div className="p-6">
          <div className="space-y-4">
            {mockSongs.map((song) => <SongRow key={song.id} song={song} />)}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;