
import React from 'react';
import { LucideProps } from 'lucide-react';

interface StatCardProps {
  label: string;
  value: string;
  change: string;
  icon: React.ComponentType<LucideProps>;
  gradient: string;
  detail: string;
}

const StatCard: React.FC<StatCardProps> = ({ label, value, change, icon: Icon, gradient, detail }) => {
  return (
    <div className="bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden group hover:shadow-2xl hover:-translate-y-1 transition-all duration-300">
      <div className={`h-2 bg-gradient-to-r ${gradient}`}></div>
      <div className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className={`bg-gradient-to-br ${gradient} p-3 rounded-xl text-white shadow-md`}>
            <Icon size={24} />
          </div>
          <div className="text-right">
            <p className="text-3xl font-bold text-gray-900">{value}</p>
            <p className="text-sm text-green-600 font-medium">{change}</p>
          </div>
        </div>
        <div>
          <p className="text-gray-700 font-semibold">{label}</p>
          <p className="text-gray-500 text-sm">{detail}</p>
        </div>
      </div>
    </div>
  );
};

export default StatCard;
