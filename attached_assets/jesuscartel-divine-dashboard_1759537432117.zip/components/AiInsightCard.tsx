
import React from 'react';
import { AiInsight, AiInsightType } from '../types';
import { TrendingUp, Brain, Film, Lightbulb } from './icons';

interface AiInsightCardProps {
  insight: AiInsight;
}

const getInsightIcon = (type: AiInsightType) => {
  switch (type) {
    case 'revenue_boost': return TrendingUp;
    case 'trend_prediction': return Brain;
    case 'sync_match': return Film;
    default: return Lightbulb;
  }
};

const AiInsightCard: React.FC<AiInsightCardProps> = ({ insight }) => {
  const Icon = getInsightIcon(insight.type);

  return (
    <div className="bg-white rounded-xl p-6 shadow-lg border border-gray-100 hover:shadow-xl hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between">
      <div>
        <div className="flex items-start space-x-4">
          <div className="bg-purple-100 p-3 rounded-lg flex-shrink-0">
            <Icon className="text-purple-600" size={24} />
          </div>
          <div className="flex-1">
            <h4 className="font-bold text-gray-900 mb-2">{insight.title}</h4>
            <p className="text-gray-600 text-sm mb-3">{insight.message}</p>
          </div>
        </div>
      </div>
      <div className="flex items-center justify-between mt-4">
        <div className="flex items-center space-x-2">
          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
          <span className="text-xs text-gray-500">{insight.confidence}% confidence</span>
        </div>
        <button className="text-purple-600 hover:text-purple-800 text-sm font-medium hover:underline">
          {insight.action}
        </button>
      </div>
    </div>
  );
};

export default AiInsightCard;
