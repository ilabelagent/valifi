
import React, { useState } from 'react';
import { Song, SongStatus } from '../types';
import { Shield, Brain, TrendingUp, Play, Pause } from './icons';

interface SongRowProps {
  song: Song;
}

const StatusBadge: React.FC<{ status: SongStatus }> = ({ status }) => {
  const statusConfig = {
    blockchain_verified: {
      Icon: Shield,
      text: 'Blockchain Verified',
      style: 'bg-green-100 text-green-800',
    },
    ai_optimized: {
      Icon: Brain,
      text: 'AI Optimized',
      style: 'bg-purple-100 text-purple-800',
    },
    trending: {
      Icon: TrendingUp,
      text: 'Trending',
      style: 'bg-orange-100 text-orange-800',
    },
    new: {
        Icon: TrendingUp,
        text: 'New',
        style: 'bg-blue-100 text-blue-800',
    }
  };

  const config = statusConfig[status];
  if (!config) return null;

  return (
    <span className={`${config.style} px-2 py-1 rounded-full text-xs font-bold flex items-center space-x-1 whitespace-nowrap`}>
      <config.Icon size={12} />
      <span>{config.text}</span>
    </span>
  );
};

const SongRow: React.FC<SongRowProps> = ({ song }) => {
  const [isPlaying, setIsPlaying] = useState(false);

  return (
    <div className="flex items-center space-x-4 p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors duration-200">
      <div className="text-3xl">{song.cover}</div>
      <div className="flex-1">
        <div className="flex items-center space-x-3 mb-1">
          <h4 className="font-bold text-gray-900">{song.title}</h4>
          <StatusBadge status={song.status} />
        </div>
        <p className="text-gray-600 text-sm">{song.artist} • Produced by {song.producer}</p>
        <div className="flex items-center space-x-4 mt-2 text-sm text-gray-500">
          <span>${song.revenue.toLocaleString()} revenue</span>
          <span>•</span>
          <span>{song.streams.toLocaleString()} streams</span>
          <span>•</span>
          <span>{song.syncOpportunities} sync opportunities</span>
        </div>
      </div>
      <div className="flex items-center space-x-4">
        <div className="text-right">
          <div className="text-sm text-gray-500">AI Score</div>
          <div className="text-xl font-bold text-purple-600">{song.aiScore}</div>
        </div>
        <button 
          onClick={() => setIsPlaying(!isPlaying)}
          className="bg-purple-600 hover:bg-purple-700 text-white w-12 h-12 rounded-full flex items-center justify-center transition-all duration-200 shadow-lg hover:scale-110"
        >
          {isPlaying ? <Pause size={20} /> : <Play size={20} className="ml-1" />}
        </button>
      </div>
    </div>
  );
};

export default SongRow;
