
import React from 'react';
import { ArtistData } from '../types';

interface ArtistCardProps {
  artist: string;
  data: ArtistData;
}

const ArtistCard: React.FC<ArtistCardProps> = ({ artist, data }) => {
  const getEmoji = (artistName: string): string => {
    switch(artistName) {
      case 'Sunday': return '🎤';
      case 'iMan': return '🎧';
      case 'Ebube': return '✍️';
      default: return '👤';
    }
  };
  
  const getRole = (artistName: string): string => {
     switch(artistName) {
      case 'Sunday': return 'Vocalist';
      case 'iMan': return 'Producer';
      case 'Ebube': return 'Writer';
      default: return 'Artist';
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100 hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
      <div className="flex items-center space-x-4 mb-4">
        <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center text-3xl shadow-md">
          {getEmoji(artist)}
        </div>
        <div>
          <h3 className="text-xl font-bold text-gray-900">{artist}</h3>
          <p className="text-gray-500">{getRole(artist)}</p>
        </div>
      </div>
      <div className="space-y-3">
        <div className="flex justify-between items-center text-sm">
          <span className="text-gray-600">Songs</span>
          <span className="font-bold text-gray-800">{data.songs}</span>
        </div>
        <div className="flex justify-between items-center text-sm">
          <span className="text-gray-600">Revenue</span>
          <span className="font-bold text-green-600">${data.revenue.toLocaleString()}</span>
        </div>
        <div className="flex justify-between items-center text-sm">
          <span className="text-gray-600">Streams</span>
          <span className="font-bold text-gray-800">{data.streams.toLocaleString()}</span>
        </div>
        <div className="flex justify-between items-center text-sm">
          <span className="text-gray-600">Growth</span>
          <span className="font-bold text-purple-600">{data.growth}</span>
        </div>
      </div>
    </div>
  );
};

export default ArtistCard;
