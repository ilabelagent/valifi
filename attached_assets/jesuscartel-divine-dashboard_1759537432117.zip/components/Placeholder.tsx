
import React from 'react';
import { Crown } from './icons';

interface PlaceholderProps {
  sectionName: string;
}

const Placeholder: React.FC<PlaceholderProps> = ({ sectionName }) => {
  return (
    <div className="flex items-center justify-center h-full min-h-[50vh] bg-white rounded-2xl shadow-lg border border-gray-100">
      <div className="text-center p-8">
        <Crown className="mx-auto text-purple-300 mb-6" size={64} />
        <h2 className="text-2xl font-bold text-gray-700 capitalize mb-2">{sectionName}</h2>
        <p className="text-gray-500 text-lg">This heavenly feature is coming soon.</p>
        <p className="text-gray-400 text-sm mt-1">Our divine developers are working on this section.</p>
      </div>
    </div>
  );
};

export default Placeholder;
