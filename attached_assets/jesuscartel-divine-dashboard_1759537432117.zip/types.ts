
export type Section = 
  | 'dashboard'
  | 'songs'
  | 'artists'
  | 'royalties'
  | 'ai-assistant'
  | 'sync'
  | 'blockchain'
  | 'analytics'
  | 'mobile'
  | 'settings';

export interface ArtistData {
  songs: number;
  revenue: number;
  streams: number;
  growth: string;
}

export interface ArtistProfile {
  [key: string]: ArtistData;
}

export type SongStatus = 'blockchain_verified' | 'ai_optimized' | 'trending' | 'new';

export interface Song {
  id: number;
  title: string;
  artist: string;
  writers: string[];
  producer: string;
  status: SongStatus;
  revenue: number;
  streams: number;
  aiScore: number;
  syncOpportunities: number;
  cover: string;
}

export type AiInsightType = "revenue_boost" | "trend_prediction" | "sync_match";

export interface AiInsight {
  type: AiInsightType;
  title: string;
  message: string;
  confidence: number;
  action: string;
}
