
class TTSService {
  private utterance: SpeechSynthesisUtterance | null = null;
  private onEndCallback: (() => void) | null = null;

  constructor() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      this.utterance = new SpeechSynthesisUtterance();
      this.utterance.onend = () => {
        if (this.onEndCallback) {
          this.onEndCallback();
        }
      };
      // Optional: Set default voice, rate, pitch if desired
      // const voices = window.speechSynthesis.getVoices();
      // if (voices.length > 0) this.utterance.voice = voices[0]; // Example: set a default voice
      // this.utterance.rate = 1; 
      // this.utterance.pitch = 1;
    }
  }

  speak(text: string, onEnd?: () => void): void {
    if (!this.utterance || !window.speechSynthesis) {
      console.warn('Speech synthesis not supported or initialized.');
      if (onEnd) onEnd(); // Call onEnd to prevent UI from getting stuck if TTS fails
      return;
    }
    this.onEndCallback = onEnd || null;
    this.utterance.text = text;
    window.speechSynthesis.cancel(); // Cancel any previous speech
    window.speechSynthesis.speak(this.utterance);
  }

  pause(): void {
    if (window.speechSynthesis && window.speechSynthesis.speaking) {
      window.speechSynthesis.pause();
    }
  }

  resume(): void {
    if (window.speechSynthesis && window.speechSynthesis.paused) {
      window.speechSynthesis.resume();
    }
  }

  cancel(): void {
    if (window.speechSynthesis) {
      window.speechSynthesis.cancel();
      // Ensure onEndCallback is called if speech is cancelled externally
      // and a callback was provided for the current utterance
      if (this.onEndCallback) {
        this.onEndCallback();
        this.onEndCallback = null; // Reset callback after use
      }
    }
  }

  isPlaying(): boolean {
    return window.speechSynthesis ? window.speechSynthesis.speaking : false;
  }

  isPaused(): boolean {
    return window.speechSynthesis ? window.speechSynthesis.paused : false;
  }
}

const ttsService = new TTSService();
export default ttsService;