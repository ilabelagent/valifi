
import React from 'react';

interface IconProps {
  path: string;
  className?: string;
  viewBox?: string;
}

const Icon: React.FC<IconProps> = ({ path, className = "w-5 h-5", viewBox = "0 0 20 20" }) => {
  return (
    <svg className={className} fill="currentColor" viewBox={viewBox} xmlns="http://www.w3.org/2000/svg">
      <path fillRule="evenodd" d={path} clipRule="evenodd" />
    </svg>
  );
};

export const PlayIcon: React.FC<{className?: string}> = ({className}) => <Icon path="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" className={className} />;
export const PauseIcon: React.FC<{className?: string}> = ({className}) => <Icon path="M10 18a8 8 0 100-16 8 8 0 000 16zM9 6a1 1 0 00-1 1v6a1 1 0 102 0V7a1 1 0 00-1-1zm4 0a1 1 0 00-1 1v6a1 1 0 102 0V7a1 1 0 00-1-1z" className={className} />;
export const StopIcon: React.FC<{className?: string}> = ({className}) => <Icon path="M10 18a8 8 0 100-16 8 8 0 000 16zm-1-5a1 1 0 00-1 1v2a1 1 0 102 0v-2a1 1 0 00-1-1zm0-5a1 1 0 00-1 1v2a1 1 0 102 0V9a1 1 0 00-1-1zM5 9.5A1.5 1.5 0 016.5 8h7a1.5 1.5 0 010 3h-7A1.5 1.5 0 015 9.5z" className={className} />; // Placeholder, better Stop icon needed
export const SparklesIcon: React.FC<{className?: string}> = ({className}) => <Icon path="M12.654.436a.75.75 0 01.638.046l2.5 1.75a.75.75 0 01.11.96l-.087.143-.001.002-1.295 2.147a.75.75 0 01-1.18.215l-.078-.063-2.022-1.517a.75.75 0 01-.215-1.18l.063-.078L12.449.546a.75.75 0 01.205-.11zm-5.308 0a.75.75 0 01.205.11L9.006 2.063a.75.75 0 01-.152 1.258L6.83 4.838a.75.75 0 01-1.258-.152l-.063-.078-1.75-2.5a.75.75 0 01.046-.638l.064-.087.002-.001L5.91.436a.75.75 0 01.436-.046l.078.012.087.024.087.036.087.048.075.05.012.008zm10.278 6.018a.75.75 0 01.046.638l-1.75 2.5a.75.75 0 01-.96.11l-.143-.087-.002-.001-2.147-1.295a.75.75 0 01-.215-1.18l.063-.078 1.517-2.022a.75.75 0 011.18-.215l.078.063.075.05.012.007.087.064.087.075.087.087.075.087.063.087.05.075.036.087.024.087.012.078zm-13.846-.01a.75.75 0 01.638-.046l2.5-1.75a.75.75 0 01.11-.96l-.087-.143-.001-.002-1.295-2.147a.75.75 0 01-1.18-.215l-.078.063-2.022 1.517a.75.75 0 01-.215 1.18l.063.078 1.455 1.937a.75.75 0 01.047.638l-.01.078.012.075.024.087.036.087.05.087.063.075.075.063.087.05.087.036.087.024.078.012zM12 5.25a.75.75 0 01.75.75v3a.75.75 0 01-1.5 0V6a.75.75 0 01.75-.75zm-3.75 3a.75.75 0 01.75.75v3a.75.75 0 01-1.5 0v-3a.75.75 0 01.75-.75zm7.5 0a.75.75 0 01.75.75v3a.75.75 0 01-1.5 0v-3a.75.75 0 01.75-.75zm-3.75 3.75a.75.75 0 01.75.75v3a.75.75 0 01-1.5 0v-3a.75.75 0 01.75-.75z" viewBox="0 0 24 24" className={className}/>
export const CalendarIcon: React.FC<{className?: string}> = ({className}) => <Icon path="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5v9h10V7H6z" className={className} />;
export const ImageIcon: React.FC<{className?: string}> = ({className}) => <Icon path="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4V5h12v10zM7 8a1 1 0 11-2 0 1 1 0 012 0z" className={className} />;
export const LightBulbIcon: React.FC<{className?: string}> = ({className}) => <Icon path="M9 2a1 1 0 00-1 1v1a3 3 0 00-3 3v1c0 .531.102 1.037.288 1.5H3a1 1 0 100 2h2.288A3.001 3.001 0 009 15v1a1 1 0 102 0v-1a3.001 3.001 0 004.712-1.5H18a1 1 0 100-2h-2.288A3.001 3.001 0 0013 8V7a3 3 0 00-3-3V3a1 1 0 00-1-1zm1 11a1 1 0 100 2 1 1 0 000-2z" className={className} />;

export default Icon;