
import React from 'react';

const LoadingSpinner: React.FC<{ size?: string; text?: string }> = ({ size = 'w-8 h-8', text }) => {
  return (
    <div className="flex flex-col items-center justify-center">
      <div 
        className={`animate-spin rounded-full ${size} border-t-2 border-b-2 border-sky-500`}
      ></div>
      {text && <p className="mt-2 text-sky-400">{text}</p>}
    </div>
  );
};

export default LoadingSpinner;