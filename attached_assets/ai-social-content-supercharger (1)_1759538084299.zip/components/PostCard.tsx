
import React, { useState } from 'react';
import { PostContent } from '../types';
import LoadingSpinner from './LoadingSpinner';
import TTSControls from './TTSControls';
import { CalendarIcon, ImageIcon, SparklesIcon, LightBulbIcon } from './Icon';

interface PostCardProps {
  post: PostContent;
  onGenerateImage: (postId: string, promptText: string) => Promise<void>;
  onSchedule: (postId: string, dateTime: Date) => void;
  onEnhance: (postId: string) => Promise<void>;
  isEnhancing: boolean;
}

const PostCard: React.FC<PostCardProps> = ({ post, onGenerateImage, onSchedule, onEnhance, isEnhancing }) => {
  const [showScheduler, setShowScheduler] = useState(false);
  const [scheduleDate, setScheduleDate] = useState('');
  const [scheduleTime, setScheduleTime] = useState('');

  const handleScheduleSubmit = () => {
    if (scheduleDate && scheduleTime) {
      const dateTime = new Date(`${scheduleDate}T${scheduleTime}`);
      onSchedule(post.id, dateTime);
      setShowScheduler(false);
      setScheduleDate('');
      setScheduleTime('');
    } else {
      alert("Please select both date and time.");
    }
  };

  const imagePrompt = `${post.title}. ${post.content}`;

  return (
    <div className="bg-gray-800 shadow-xl rounded-lg p-5 hover:shadow-sky-500/30 transition-shadow duration-300 ease-in-out flex flex-col justify-between min-h-[450px]">
      <div>
        <h3 className="text-xl font-semibold text-sky-400 mb-2 flex items-center">
          <LightBulbIcon className="w-6 h-6 mr-2 text-yellow-400 flex-shrink-0" />
          <span className="truncate" title={post.title}>{post.title}</span>
        </h3>
        <p className="text-gray-300 mb-3 text-sm leading-relaxed h-20 overflow-y-auto">{post.content}</p>
        <div className="mb-3 flex flex-wrap gap-2">
          {post.hashtags.map((tag, index) => (
            <span key={index} className="px-2 py-1 bg-sky-700 text-sky-200 rounded-full text-xs font-medium">
              {tag}
            </span>
          ))}
        </div>
        <p className="text-xs text-gray-500 mb-4">Platform: <span className="font-semibold text-sky-500">{post.platform}</span></p>

        {post.isImageLoading ? (
          <div className="w-full h-48 flex items-center justify-center bg-gray-700 rounded mb-3">
            <LoadingSpinner text="Generating image..." />
          </div>
        ) : post.imageUrl ? (
          <img src={post.imageUrl} alt={post.title} className="w-full h-48 object-cover rounded mb-3 border border-gray-700" />
        ) : (
          <div className="w-full h-48 flex items-center justify-center bg-gray-700 rounded mb-3 text-gray-500 text-center p-4">
            Click "Generate Image" to create a visual for this post.
          </div>
        )}
      </div>

      <div className="mt-auto pt-4 border-t border-gray-700/50">
        <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
          <TTSControls textToSpeak={`${post.title}. ${post.content}`} />
          <button
            onClick={() => onGenerateImage(post.id, imagePrompt)}
            disabled={post.isImageLoading || isEnhancing}
            className="flex items-center px-3 py-2 bg-green-600 hover:bg-green-700 text-white text-xs sm:text-sm font-medium rounded-md shadow-sm transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <ImageIcon className="w-4 h-4 mr-1 sm:mr-2" />
            {post.imageUrl ? 'Re-Gen Image' : 'Gen Image'}
          </button>
        </div>
        <div className="flex items-center justify-between flex-wrap gap-2">
           <button
            onClick={() => onEnhance(post.id)}
            disabled={isEnhancing || post.isImageLoading}
            className="flex items-center px-3 py-2 bg-purple-600 hover:bg-purple-700 text-white text-xs sm:text-sm font-medium rounded-md shadow-sm transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <SparklesIcon className="w-4 h-4 mr-1 sm:mr-2" />
            AI Enhance
          </button>
          <button
            onClick={() => setShowScheduler(true)}
            disabled={isEnhancing || post.isImageLoading}
            className="flex items-center px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs sm:text-sm font-medium rounded-md shadow-sm transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <CalendarIcon className="w-4 h-4 mr-1 sm:mr-2" />
            Schedule
          </button>
        </div>
        
        {post.scheduledTime && (
          <p className="text-xs text-green-400 mt-2 text-center sm:text-left">
            Scheduled: {new Date(post.scheduledTime).toLocaleDateString()} {new Date(post.scheduledTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </p>
        )}
      </div>

      {showScheduler && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black bg-opacity-75 p-4">
          <div className="bg-gray-800 p-6 rounded-lg shadow-xl w-full max-w-sm border border-sky-600">
            <h4 className="text-lg font-semibold text-sky-400 mb-1">Schedule Post</h4>
            <p className="text-xs text-gray-400 mb-4 truncate" title={post.title}>Title: {post.title}</p>
            <div className="mb-4">
              <label htmlFor={`scheduleDate-${post.id}`} className="block text-sm font-medium text-gray-300 mb-1">Date</label>
              <input 
                type="date" 
                id={`scheduleDate-${post.id}`}
                value={scheduleDate}
                min={new Date().toISOString().split('T')[0]} // Prevent past dates
                onChange={(e) => setScheduleDate(e.target.value)}
                className="w-full p-2 bg-gray-700 border border-gray-600 rounded-md text-gray-200 focus:ring-2 focus:ring-sky-500 focus:border-sky-500 appearance-none"
              />
            </div>
            <div className="mb-6">
              <label htmlFor={`scheduleTime-${post.id}`} className="block text-sm font-medium text-gray-300 mb-1">Time</label>
              <input 
                type="time" 
                id={`scheduleTime-${post.id}`}
                value={scheduleTime}
                onChange={(e) => setScheduleTime(e.target.value)}
                className="w-full p-2 bg-gray-700 border border-gray-600 rounded-md text-gray-200 focus:ring-2 focus:ring-sky-500 focus:border-sky-500 appearance-none"
              />
            </div>
            <div className="flex justify-end space-x-3">
              <button onClick={() => setShowScheduler(false)} className="px-4 py-2 text-gray-300 hover:bg-gray-700 rounded-md transition-colors">Cancel</button>
              <button onClick={handleScheduleSubmit} className="px-4 py-2 bg-sky-600 hover:bg-sky-700 text-white rounded-md transition-colors">Confirm Schedule</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PostCard;