
import React, { useState, useEffect, useCallback } from 'react';
import ttsService from '../services/ttsService';
import { PlayIcon, PauseIcon, StopIcon } from './Icon';

interface TTSControlsProps {
  textToSpeak: string;
  buttonSize?: string;
}

const TTSControls: React.FC<TTSControlsProps> = ({ textToSpeak, buttonSize = "w-6 h-6" }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isPaused, setIsPaused] = useState(false);

  const handlePlay = useCallback(() => {
    if (isPaused) {
      ttsService.resume();
    } else {
      ttsService.speak(textToSpeak, () => {
        setIsPlaying(false);
        setIsPaused(false);
      });
    }
    setIsPlaying(true);
    setIsPaused(false);
  }, [textToSpeak, isPaused]);

  const handlePause = useCallback(() => {
    ttsService.pause();
    setIsPlaying(false);
    setIsPaused(true);
  }, []);

  const handleStop = useCallback(() => {
    ttsService.cancel();
    setIsPlaying(false);
    setIsPaused(false);
  }, []);

  useEffect(() => {
    // Cleanup synthesis on component unmount or text change
    return () => {
      // Only cancel if this specific instance was managing active speech
      if ((ttsService.isPlaying() || ttsService.isPaused()) && ttsService.utterance?.text === textToSpeak) {
         ttsService.cancel();
      }
      setIsPlaying(false);
      setIsPaused(false);
    };
  }, [textToSpeak]);
  
  // Update state based on global ttsService state (e.g. if another component stops TTS)
  useEffect(() => {
    const interval = setInterval(() => {
      const currentServicePlaying = ttsService.isPlaying();
      const currentServicePaused = ttsService.isPaused();

      // Only update if the current text is what's being managed by TTS
      // This helps avoid conflicts if multiple TTSControls are on the page for different texts.
      // However, if any TTS stops, all should reflect no playback.
      if (!currentServicePlaying && !currentServicePaused) {
        if (isPlaying || isPaused) {
            setIsPlaying(false);
            setIsPaused(false);
        }
      } else if (ttsService.utterance?.text === textToSpeak) {
          if (currentServicePlaying !== isPlaying) setIsPlaying(currentServicePlaying);
          if (currentServicePaused !== isPaused) setIsPaused(currentServicePaused);
      } else {
        // If TTS is active but for a different text, this instance should show as stopped.
        if (isPlaying || isPaused) {
            setIsPlaying(false);
            setIsPaused(false);
        }
      }
    }, 200);
    return () => clearInterval(interval);
  }, [isPlaying, isPaused, textToSpeak]);


  if (!textToSpeak) return null;

  return (
    <div className="flex items-center space-x-2">
      {!isPlaying && !isPaused && (
        <button
          onClick={handlePlay}
          className="p-2 rounded-full text-gray-300 hover:bg-sky-700 hover:text-sky-300 transition-colors focus:outline-none focus:ring-2 focus:ring-sky-500"
          aria-label="Play"
        >
          <PlayIcon className={buttonSize} />
        </button>
      )}
      {isPlaying && !isPaused && (
        <button
          onClick={handlePause}
          className="p-2 rounded-full text-gray-300 hover:bg-sky-700 hover:text-sky-300 transition-colors focus:outline-none focus:ring-2 focus:ring-sky-500"
          aria-label="Pause"
        >
          <PauseIcon className={buttonSize} />
        </button>
      )}
      {isPaused && (
         <button
          onClick={handlePlay} // Resume is handled by play logic
          className="p-2 rounded-full text-gray-300 hover:bg-sky-700 hover:text-sky-300 transition-colors focus:outline-none focus:ring-2 focus:ring-sky-500"
          aria-label="Resume"
        >
          <PlayIcon className={buttonSize} />
        </button>
      )}
      {(isPlaying || isPaused) && (
        <button
          onClick={handleStop}
          className="p-2 rounded-full text-gray-300 hover:bg-red-700 hover:text-red-300 transition-colors focus:outline-none focus:ring-2 focus:ring-red-500"
          aria-label="Stop"
        >
          <StopIcon className={buttonSize} />
        </button>
      )}
    </div>
  );
};

export default TTSControls;