
export interface PostContent {
  id: string;
  title: string;
  content: string;
  hashtags: string[];
  platform: string;
  imageUrl?: string;
  isImageLoading?: boolean;
  scheduledTime?: Date;
}

export interface GeneratedPostData {
  title: string;
  content: string;
  hashtags: string[];
  platform: string;
}

export interface GeminiExplanationAndPostsResponse {
  explanation: string;
  posts: GeneratedPostData[];
}

export enum SocialPlatform {
  TikTok = "TikTok",
  Instagram = "Instagram",
  WhatsApp = "WhatsApp",
  Twitter = "Twitter",
  Facebook = "Facebook",
  LinkedIn = "LinkedIn",
  General = "General",
}