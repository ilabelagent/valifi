
export const GEMINI_TEXT_MODEL = 'gemini-2.5-flash-preview-04-17';
export const GEMINI_IMAGE_MODEL = 'imagen-3.0-generate-002';

// Truncated for brevity in this example. The actual app would use the full text.
export const USER_PROVIDED_TEXT_CONTENT = `
The Compendium of Divine Faith Manifestation: A Living Manual
Cultivating a Life of God-Centered Manifestation Through Jesus Christ
Part 1: How to Approach and Edit This Research Plan (Methodology for Continuous Learning)
This manual is designed not as a static document to be read once and set aside, but as a dynamic, living framework for your ongoing journey of faith manifestation. It’s intended to be actively edited, continuously expanded upon, and deeply personalized as you grow in revelation and experience with God. Consider this less of a conventional book and more of your primary, evolving textbook for Kingdom living, meticulously designed to be adaptable to every season, challenge, and triumph in your walk with God. Its "living" nature means it grows with you, reflecting your deepening understanding and the specific ways God manifests His power in your life.

1.1 Understanding the Modular Structure
This compendium is thoughtfully organized into distinct, yet profoundly interconnected, parts. Each section plays a vital role in building a holistic understanding and practical application of faith manifestation. Understanding their individual purposes and how they weave together is key to maximizing this manual's effectiveness.

Part 1: Methodology: This foundational section guides you on precisely how to best utilize, adapt, and interact with this comprehensive document. It sets the stage for active engagement, ensuring you treat this manual as a dynamic tool for growth, not just passive information.

Part 2: Deeper Dive into Foundations: This serves as your core theological and practical research library. It provides exhaustive commentary, historical context, and expanded scriptural insights for each core principle of faith manifestation. Think of it as your "reference book" for in-depth understanding, offering the robust intellectual and spiritual grounding necessary for unshakable faith.

Part 3: The Manual for Post-Living & Revision (The Scenario Encyclopedia): This is the heart of practical, real-world application. It addresses common life scenarios and provides concrete, scriptural, and actionable responses. This section acts as your personal "troubleshooting guide" and "battle manual," equipping you to navigate specific challenges with divine wisdom and authority. It's where theory meets practice in the everyday.

Part 4: Comprehensive Cheat Sheets & Gradual Living Guides: This section offers concise summaries, quick reference points, and progressive plans for seamlessly integrating these powerful principles into your daily, weekly, and monthly routines. This acts as your "quick reference" for immediate application and your "daily planner" for sustained spiritual discipline.

1.2 Recommendations for Adaptation and Personalization
The true power of this manual unfolds as you make it uniquely your own. Embrace these recommendations to transform it into a deeply personal and effective tool for your spiritual journey.

Printable & Digital Versatility: This document is meticulously formatted in Markdown, allowing for effortless copying into popular word processors like Microsoft Word or Google Docs. This versatility enables you to print out sections for a tactile, note-taking experience with pen and paper, or to leverage digital platforms for dynamic editing, robust search capabilities, and easy sharing of your personalized insights. Choose the format that best suits your learning and engagement style.

Enriching Personal Notes & Insights: Dedicate ample space within each chapter for your profound personal revelations, specific, heartfelt prayers, and documented answered testimonies. Also, create sections for new scriptural cross-references that the Holy Spirit illuminates for you. This practice transforms the manual into a spiritual autobiography, charting your unique journey of faith and capturing the whispers of God to your heart.

Expanding Your Scenario Encyclopedia: As you inevitably encounter new and varied life situations, actively add them to Part 3. Document your specific approach, detail the faith manifestation principles you applied, and meticulously record the outcome. This iterative process builds an invaluable, unique "scenario encyclopedia" tailored to your experiences, creating a rich repository of applied wisdom that you can refer to in future challenges.

Strategic Version Control (Personal): Implement a simple personal versioning system. Consider dating your major edits or creating distinct "versions" of your notes. For example, you might label sections like "Faith Foundation - Version 1.0 (Initial Study)" and later, "Faith Foundation - Version 2.0 (After Breakthrough X)." This not only helps track your growth and understanding over time but also allows you to revisit past stages of your faith walk, identify patterns in God's faithfulness, and observe your own spiritual maturity develop.

Dynamic Cross-Referencing for Deeper Revelation: Make it a conscious practice to actively link concepts and scriptures across various sections of this compendium. For instance, when delving into the "Prayer" section, make explicit notes on how it powerfully connects to "Power of the Spoken Word" and "The Mind and Imagination." This practice fosters a holistic, interconnected understanding of faith principles, leading to deeper revelation and a more robust, integrated spiritual life.

1.3 Guidance on Continuous Learning and Revision
This manual is a catalyst for an ongoing, dynamic process of spiritual growth. Its effectiveness is directly proportional to your consistent engagement and willingness to learn, adapt, and refine your approach.

Daily Engagement as a Lifestyle: This manual is not intended for occasional, passive reading. Instead, make it an integral part of your daily spiritual rhythm. Integrate specific sections into your devotional time, perhaps focusing on one principle each day or week. Even short, focused micro-sessions of study and reflection can yield profound results, gradually transforming your perspective and habits.

Reflect and Refine for Greater Clarity: Make time for regular, honest review of your notes and experiences. Ask yourself incisive questions: "What worked effectively in that situation, and why? What didn't yield the expected results, and what lessons can I glean from that? What new insights or promptings has the Holy Spirit illuminated for me through this experience or scripture?" This critical reflection process allows you to distill profound wisdom from your journey and refine your application of these principles.

Test and Experiment with Audacious Faith: The "Experiments" outlined within each section are not optional suggestions; they are crucial practical drills for exercising and strengthening your faith. Faith, like a muscle, grows by being actively exercised. Don't merely read about these principles; do them. Document your results meticulously, understanding that even unexpected outcomes hold valuable lessons. Embrace the journey of active faith, allowing each experiment to build your confidence and trust in God's power.

Share and Teach to Solidify Understanding: One of the most effective ways to deeply internalize these principles and solidify your own understanding is to articulate and teach them to others. As you explain these truths, mentor fellow believers, or share your testimonies, you will often find areas where your own knowledge needs strengthening, or new dimensions of understanding will emerge. This reciprocal process of sharing and teaching becomes a powerful feedback loop for your own growth.

Cultivate Humility and Openness to Divine Guidance: Always approach God's Word and your spiritual journey with profound humility and an open heart. Be receptive to new understanding and correction by the Holy Spirit. Avoid rigid dogma and be willing to adjust your perspective as God reveals deeper truths. Faith is a lifelong journey of learning, growing, and drawing ever closer to the Divine, constantly evolving in revelation and application. Embrace the process, trust the Guide, and allow Him to lead you into ever-increasing dimensions of manifestation.
---
[THE REST OF THE VERY LONG TEXT PROVIDED BY THE USER WOULD GO HERE. IT IS OMITTED FOR BREVITY IN THIS EXAMPLE RESPONSE, BUT THE APP SHOULD BE ABLE TO HANDLE THE FULL TEXT.]
---
`;