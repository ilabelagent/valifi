
import React, { useState, useCallback, useEffect } from 'react';
import { PostContent, GeneratedPostData, GeminiExplanationAndPostsResponse } from './types';
import { USER_PROVIDED_TEXT_CONTENT } from './constants';
import * as geminiService from './services/geminiService';
import PostCard from './components/PostCard';
import LoadingSpinner from './components/LoadingSpinner';
import TTSControls from './components/TTSControls';
import { LightBulbIcon, SparklesIcon } from './components/Icon'; // Added SparklesIcon for consistency

const App: React.FC = () => {
  const [inputText, setInputText] = useState<string>(USER_PROVIDED_TEXT_CONTENT);
  const [explanation, setExplanation] = useState<string>('');
  const [generatedPosts, setGeneratedPosts] = useState<PostContent[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isEnhancingPostId, setIsEnhancingPostId] = useState<string | null>(null);
  const [error, setError] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'generate' | 'scheduled'>('generate');


  useEffect(() => {
    // Check for API Key on mount and inform user if not set
    if (!process.env.API_KEY) {
      setError("Gemini API Key is not configured. Please ensure the API_KEY environment variable is set for full functionality.");
    }
  }, []);

  const handleAnalyzeAndBreakdown = useCallback(async () => {
    if (!inputText.trim()) {
      setError('Please enter some text to analyze.');
      return;
    }
    setIsLoading(true);
    setError('');
    setExplanation('');
    setGeneratedPosts([]);
    setActiveTab('generate'); // Reset to generate tab

    try {
      const result: GeminiExplanationAndPostsResponse = await geminiService.getExplanationAndBreakdown(inputText);
      setExplanation(result.explanation);
      const postsWithIds: PostContent[] = result.posts.map((post, index) => ({
        ...post,
        id: `post-${Date.now()}-${index}`,
        imageUrl: undefined,
        isImageLoading: false,
        scheduledTime: undefined,
      }));
      setGeneratedPosts(postsWithIds);
    } catch (err) {
      console.error(err);
      const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred.';
      setError(`Failed to process text: ${errorMessage}. Check console for details. Ensure your API key is valid and has access to the models.`);
      setExplanation('');
      setGeneratedPosts([]);
    } finally {
      setIsLoading(false);
    }
  }, [inputText]);

  const handleGenerateImage = useCallback(async (postId: string, promptText: string) => {
    setGeneratedPosts(prevPosts =>
      prevPosts.map(p => (p.id === postId ? { ...p, isImageLoading: true, imageUrl: undefined } : p))
    );
    setError('');
    try {
      const imageUrl = await geminiService.generateImageForText(promptText);
      setGeneratedPosts(prevPosts =>
        prevPosts.map(p => (p.id === postId ? { ...p, imageUrl, isImageLoading: false } : p))
      );
    } catch (err) {
      console.error(err);
      const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred.';
      setError(`Failed to generate image for post. ${errorMessage}`);
      setGeneratedPosts(prevPosts =>
        prevPosts.map(p => (p.id === postId ? { ...p, isImageLoading: false } : p))
      );
    }
  }, []);

  const handleSchedulePost = useCallback((postId: string, dateTime: Date) => {
    setGeneratedPosts(prevPosts =>
      prevPosts.map(p => (p.id === postId ? { ...p, scheduledTime: dateTime } : p))
    );
    // In a real app, this would likely send to a backend or local storage
    // For now, an alert is fine for user feedback.
    // alert(`Post "${generatedPosts.find(p=>p.id===postId)?.title}" scheduled for ${dateTime.toLocaleString()}`);
  }, []);

  const handleEnhancePost = useCallback(async (postId: string) => {
    const postToEnhance = generatedPosts.find(p => p.id === postId);
    if (!postToEnhance) return;

    setIsEnhancingPostId(postId);
    setError('');
    try {
      const enhancedData: GeneratedPostData = await geminiService.enhancePostContent(postToEnhance.content, postToEnhance.title, postToEnhance.platform);
      setGeneratedPosts(prevPosts =>
        prevPosts.map(p => (p.id === postId ? { 
            ...p, 
            title: enhancedData.title, 
            content: enhancedData.content, 
            hashtags: enhancedData.hashtags, 
            platform: enhancedData.platform,
            // Retain id, imageUrl, isImageLoading, scheduledTime
          } : p))
      );
    } catch (err) {
      console.error(err);
      const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred.';
      setError(`Failed to enhance post. ${errorMessage}`);
    } finally {
      setIsEnhancingPostId(null);
    }
  }, [generatedPosts]);

  const scheduledPosts = generatedPosts.filter(p => p.scheduledTime).sort((a,b) => new Date(a.scheduledTime!).getTime() - new Date(b.scheduledTime!).getTime());
  const nonScheduledPosts = generatedPosts.filter(p => !p.scheduledTime);


  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 p-4 md:p-8 selection:bg-sky-500 selection:text-white">
      <header className="text-center mb-8 md:mb-10">
        <h1 className="text-4xl md:text-5xl font-bold text-sky-400">
          AI Social Content <span className="text-purple-400">Supercharger</span>
        </h1>
        <p className="text-base md:text-lg text-gray-400 mt-2 max-w-2xl mx-auto">
          Transform your long-form text into engaging social media content with the power of Gemini AI.
        </p>
      </header>

      {error && (
        <div className="bg-red-500/20 border border-red-700 text-red-300 px-4 py-3 rounded-md relative mb-6 text-sm" role="alert">
          <strong className="font-bold">Error: </strong>
          <span className="block sm:inline">{error}</span>
          <button onClick={() => setError('')} className="absolute top-0 bottom-0 right-0 px-4 py-3 text-red-400 hover:text-red-200">
            <span className="text-2xl">&times;</span>
          </button>
        </div>
      )}
      
      {/* Input Section */}
      <section className="mb-8 md:mb-10 p-4 md:p-6 bg-gray-800 rounded-xl shadow-2xl">
        <h2 className="text-xl md:text-2xl font-semibold text-sky-500 mb-4">1. Your Source Content</h2>
        <textarea
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder="Paste your long text here..."
          rows={8}
          className="w-full p-3 bg-gray-700 border border-gray-600 rounded-md text-gray-200 focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition-shadow disabled:opacity-70"
          disabled={isLoading}
        />
        <button
          onClick={handleAnalyzeAndBreakdown}
          disabled={isLoading || !process.env.API_KEY}
          className="mt-4 w-full flex items-center justify-center px-6 py-3 bg-sky-600 hover:bg-sky-700 text-white font-semibold rounded-md shadow-lg transition-all duration-150 ease-in-out disabled:opacity-50 disabled:cursor-not-allowed group"
        >
          {isLoading ? <LoadingSpinner size="w-5 h-5" /> : <SparklesIcon className="w-5 h-5 mr-2 group-hover:animate-pulse" />}
          {isLoading ? 'Processing Your Text...' : 'Explain & Generate Posts'}
        </button>
         {!process.env.API_KEY && <p className="text-xs text-yellow-500 mt-2 text-center">API Key not detected. Functionality will be limited. Please set <code className="bg-gray-700 px-1 rounded">API_KEY</code>.</p>}
      </section>

      {/* Explanation Section */}
      {explanation && !isLoading && (
        <section className="mb-8 md:mb-10 p-4 md:p-6 bg-gray-800 rounded-xl shadow-2xl">
          <div className="flex justify-between items-center mb-3">
            <h2 className="text-xl md:text-2xl font-semibold text-sky-500 flex items-center">
              <LightBulbIcon className="w-6 h-6 md:w-7 md:h-7 mr-2 text-yellow-400" />
              AI Explanation
            </h2>
            <TTSControls textToSpeak={explanation} buttonSize="w-6 h-6 md:w-7 md:h-7" />
          </div>
          <p className="text-gray-300 leading-relaxed whitespace-pre-line text-sm md:text-base">{explanation}</p>
        </section>
      )}
      
      {/* Tabs */}
      {(generatedPosts.length > 0) && !isLoading && (
        <div className="mb-6 border-b border-gray-700">
            <nav className="-mb-px flex space-x-4 sm:space-x-8" aria-label="Tabs">
            <button
                onClick={() => setActiveTab('generate')}
                className={`whitespace-nowrap pb-3 pt-1 px-1 border-b-2 font-medium text-sm sm:text-base transition-colors duration-150 ${
                activeTab === 'generate'
                    ? 'border-sky-500 text-sky-400'
                    : 'border-transparent text-gray-400 hover:text-gray-200 hover:border-gray-500'
                }`}
            >
                Generated Posts ({nonScheduledPosts.length})
            </button>
            <button
                onClick={() => setActiveTab('scheduled')}
                className={`whitespace-nowrap pb-3 pt-1 px-1 border-b-2 font-medium text-sm sm:text-base transition-colors duration-150 ${
                activeTab === 'scheduled'
                    ? 'border-purple-500 text-purple-400'
                    : 'border-transparent text-gray-400 hover:text-gray-200 hover:border-gray-500'
                }`}
            >
                Scheduled Queue ({scheduledPosts.length})
            </button>
            </nav>
        </div>
      )}


      {/* Generated/Scheduled Posts Section */}
      {!isLoading && generatedPosts.length > 0 && activeTab === 'generate' && (
        <section>
          <h2 className="text-2xl md:text-3xl font-semibold text-sky-500 mb-6">Content Ideas for You</h2>
           {nonScheduledPosts.length === 0 && <p className="text-gray-400 text-center py-8">All generated posts have been scheduled! Check the 'Scheduled Queue'.</p>}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
            {nonScheduledPosts.map(post => (
              <PostCard
                key={post.id}
                post={post}
                onGenerateImage={handleGenerateImage}
                onSchedule={handleSchedulePost}
                onEnhance={handleEnhancePost}
                isEnhancing={isEnhancingPostId === post.id}
              />
            ))}
          </div>
        </section>
      )}
      
      {!isLoading && activeTab === 'scheduled' && (
         <section>
          <h2 className="text-2xl md:text-3xl font-semibold text-purple-500 mb-6">Your Scheduled Queue</h2>
            {scheduledPosts.length === 0 && <p className="text-gray-400 text-center py-8">No posts scheduled yet. Go to "Generated Posts" to select and schedule content.</p>}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
            {scheduledPosts.map(post => (
              <PostCard
                key={post.id}
                post={post}
                onGenerateImage={handleGenerateImage}
                onSchedule={handleSchedulePost}
                onEnhance={handleEnhancePost}
                isEnhancing={isEnhancingPostId === post.id}
              />
            ))}
          </div>
        </section>
      )}


      {isLoading && !explanation && !generatedPosts.length && (
        <div className="flex flex-col items-center justify-center p-10 text-center">
          <LoadingSpinner size="w-12 h-12 md:w-16 md:h-16" />
          <p className="mt-4 text-sky-400 text-lg">AI is analyzing and crafting your content...</p>
          <p className="text-sm text-gray-500">This might take a moment, especially for very long texts.</p>
        </div>
      )}
      
      {generatedPosts.length === 0 && !isLoading && !explanation && !error && (
         <div className="text-center py-10 px-4">
            <SparklesIcon className="w-16 h-16 text-sky-600 mx-auto mb-4" />
            <h2 className="text-2xl font-semibold text-sky-400 mb-2">Ready to Supercharge Your Content?</h2>
            <p className="text-gray-400 max-w-lg mx-auto">
                Paste your text in the field above and click "Explain & Generate Posts" to let AI transform it into engaging social media updates, complete with explanations and image ideas.
            </p>
        </div>
      )}


      <footer className="text-center mt-12 py-6 border-t border-gray-700">
        <p className="text-sm text-gray-500">Powered by Gemini AI. &copy; {new Date().getFullYear()} Divine Content Solutions.</p>
      </footer>
    </div>
  );
};

export default App;