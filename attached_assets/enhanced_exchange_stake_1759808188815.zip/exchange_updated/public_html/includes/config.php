<?php
// Database Configuration
return [
    'DB_HOST' => 'localhost',
    'DB_NAME' => 'u915093727_yourckillingsh',
    'DB_USER' => 'u915093727_makewealthlike', 
    'DB_PASS' => 'Joshua3465',
    'CRON_TOKEN' => 'crypto_news_cron_token_2025_secure'
];
?>